//
//  Food+CoreDataClass.swift
//  Final-App
//
//  Created by Roro on 7/6/2024.
//
//

import Foundation
import CoreData

@objc(Food)
public class Food: NSManagedObject {

}
